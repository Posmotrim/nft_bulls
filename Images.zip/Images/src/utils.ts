import * as crypto from "crypto";
import {
  bufferToHex, ecrecover, fromRpcSig, hashPersonalMessage, publicToAddress, toBuffer
} from "ethereumjs-util";
import { createReadStream, readdirSync, readFileSync, statSync, writeFileSync } from 'fs';
import YAML from "js-yaml";
import { join, resolve } from 'path';
import {
  cwd
} from "process";

export const sortBy:<T = any>( arr:T[], getVal: ( x: T ) => string | number | Date )=>T[] = (
  arr,
  getVal
) => arr.sort( ( ...items ) => {
  const [
    a,
    b, 
  ] = items.map( ( x ) => {
    const val = getVal( x );

    if ( typeof val === "string" ) {
      return val.toLowerCase();
    }

    return val;
  } );

  return a < b ? -1 : a > b ? +1 : 0;
} );

export const fileHash = ( filePath: string ): Promise<string> => new Promise( async ( res, rej ) => {
  var fd = createReadStream( resolve( cwd(), filePath ) );
  var hash = crypto.createHash( "sha256" );

  hash.setEncoding( "hex" );
  fd.on( "end", () => {
    hash.end();
    res( hash.read() );
  } );
  fd.on( "error", rej );
  fd.pipe( hash );
} );

export function readList( file: string ) {
  try {
    const txt = readFileSync( resolve( cwd(), file ), {
      encoding : "utf-8", 
    } );
    const data = txt.trim().split( /\r?\n/ );

    return data;
  }
  catch ( e ) {
    return [];
  }
}

export function writeList( file: string, data: any ) {
  try {
    const txt = data.join( "\n" );

    writeFileSync( resolve( cwd(), file ), txt, {
      encoding : "utf-8", 
    } );
    return true;
  }
  catch ( e ) {
    return false;
  }
}

export function writeJson(file: string, data: object){
  try {
    const txt = JSON.stringify( data, null, 2);

    writeFileSync( resolve( file ), txt, {
      encoding : "utf-8", 
    } );
    return true;
  }
  catch ( e ) {
    return false;
  }
}
export function readJson(file: string, data: object){
  try {
    const txt = readFileSync( resolve( file ), {
      encoding : "utf-8", 
    } );
    return JSON.parse(txt);
  }
  catch ( e ) {
    return null;
  }
}



export function writeYaml(file: string, data: object){
  try {
    const txt = YAML.dump( data, {
      indent: 4,
      sortKeys: true,
      // flowLevel: 5,
      quotingType: '"',
      noArrayIndent: true,
      skipInvalid: true,
      schema: YAML.JSON_SCHEMA,
    });
    writeFileSync( resolve( file ), txt, {
      encoding : "utf-8", 
    } );
    return true;
  }
  catch ( e ) {
    return false;
  }
}

export function readYaml<T>(file: string):T|null{
  try {
    const txt = readFileSync( resolve( file ), {
      encoding : "utf-8", 
    } );
    return YAML.load(txt, {
      onWarning: console.log
    }) as T;
  }
  catch ( e ) {
    return null;
  }
}






export function verifySignature( msg: string, reqSignature : string, reqAddress : string ) {
  console.log( " -- verifySignature --" );
  
  const msgBuffer = toBuffer( Buffer.from( msg ) );
  const msgHash = hashPersonalMessage ( msgBuffer );
  const signatureParams = fromRpcSig( reqSignature );

  const publicKey = ecrecover(
    msgHash,
    signatureParams.v,
    signatureParams.r,
    signatureParams.s
  );

  const addressBuffer = publicToAddress( publicKey );
  const address = bufferToHex( addressBuffer );
  const valid = address && ( ( address )?.toLowerCase() === ( reqAddress )?.toLowerCase() );

  console.log( {
    valid,
    address,
    msgHash,
    publicKey,
    msg,
  } );

  return valid;
}

export function readCSV( file:string, sep:string|RegExp="\t", offsetCol=0, numCols=0 ){
  const raw = readFileSync( file, "utf-8" );

  /* Replacer */
  // const STRINGS:string[]= [];
  // raw.replace(/"[^"]+"/gi, ($0)=>{ 
  //   const id = STRINGS.length;
  //   STRINGS[id] = $0;
  //   return `{#{${id}}#}`;
  // });

  // console.log(STRINGS);
  
  const lines = raw.split( /\n/ );
  const headings = lines[0].split( sep ).slice(offsetCol, (numCols+offsetCol)||undefined);
  const data = lines.slice( 1 );
  const results: Record<string, string|number>[] = [];

  for( let i = 0; i < data.length; i++ ){
    const cols = data[i].split( sep ).slice(offsetCol, (numCols+offsetCol)||undefined);
    const item:Record<string, string|number> = {};

    let hasValue = false;
    /* 
    cols.map(( cell )=>{ 
      return cell.replace(/{#{(\d+)}#}/gi, ( $0, $1 )=>{ 
        return STRINGS[Number($1)];
      });
    }) */
    
    cols.forEach( ( val, c )=>{
      const heading = headings[c];
      if(val!=='') hasValue = true;
      item[heading] = val;
    } );
    
    if(hasValue) results.push( item ); 
  }

  return results;
}

export const recipeEncode = ( r: number[] )=> r.map( ( x ) => (
  Number( x )
    .toString( 10 )
    .padStart( 2, "0" ) 
) ).join( "-" );

export const recipeDecode = ( r: string )=> r.split( "-" ).map( ( x )=>parseInt( x, 10 ) );


export function readDirs( dir: string ){
  return readdirSync( dir )
    .map( file => join( dir, file ) )
    .filter( p => {
      const stat = statSync( p );
      return stat.isDirectory();
    } )
    .sort( ( a, b )=>{ 
      const _a = a.toLowerCase();
      const _b = b.toLowerCase();
      return _a < _b ? -1 : ( _a > _b ? 1 : 0 );
    } );
}
export function readFiles( dir: string ){
  return readdirSync( dir )
    .map( file => join( dir, file ) )
    .filter( p => {
      if( p.match( /ds_store/gi ) ) {
        return false;
      }
      const stat = statSync( p );
      return stat.isFile();
    } )
    .sort( ( a, b )=>{ 
      const _a = a.toLowerCase();
      const _b = b.toLowerCase();
      return _a < _b ? -1 : ( _a > _b ? 1 : 0 );
    } );;
}

