import chalk from "chalk";
import { execSync } from "child_process";
import { randomBytes } from "crypto";
import { appendFileSync, existsSync, linkSync, mkdirSync, writeFileSync } from "fs";
import minimist from "minimist";
import { cpus } from "os";
import { basename, dirname, join, resolve } from "path";
import sharp, { Metadata } from "sharp";
import WeightedPicker from "weighted-picker";
import { readCSV, readDirs, readFiles, readList, readYaml, recipeDecode, recipeEncode, writeYaml } from './utils';


const DATA_DIR = ( "./data" );
const SRC_DIR = join( DATA_DIR, "layers" );

export type Recipe = number[];
export type RecipeCode = string;

export interface ComposedImage {
  image: string,
  recipeCode: string,
  meta: Metadata,
  hash:string,
};

export interface SliceSpec {
  name: string,
  nameNormal?: string,
  sliceFile: string,
  fileExists?: boolean,
  weight: number
}
export interface LayerSlice {
  layerName: string,
  layerIndex: number,
  slice: SliceSpec,
}

export interface ProbTable {
  [layerName:string]: SliceSpec[],
}

export interface WeightTable {
  [layerName:string]: {
    [sliceName:string]: number,
  }
}


export interface Layer {
  name: string,
  path: string,
  slices: string[],
}

let LAYERS:Layer[] = [];
let TRACKER:Record<string, Record<string, Record< string, number >>> = {};
let UNIQUE_RECIPES: Record<string, number> = {};




/* load source images from Layers/...   */
export function loadLayers( root = "./Layers" ){
  const layerDirs = readDirs( root );
  const layers:Layer[] = [];

  layerDirs.map( ( layerDir )=>{ 
    const [id, name] = basename(layerDir).split("-");

    const files = readFiles( layerDir );
    layers[Number(id)-1] = {
      path: layerDir,
      name,
      slices: files
    }
  } );
  return layers;
}

/* recipe -> file[] */
function recipeToImages(table:WeightTable, recipe: Recipe):string[]{
  const layers = Object.entries(table);
  return recipe.map(( s, i )=>{ 
    const slices = Object.entries(layers[i][1]);
    return join("Layers", layers[i][0], slices[s][0]);
  });
}

// function freeSlot(){

// }

/* create weighted recipe */
function randomRecipe(table:WeightTable){
  let attempts = 0;
  let recipe: number[] = [];

  while(
    attempts < 100000000
  ) {
    try{
      recipe = Object.keys(table).map( (layer) => {
        const weights = Object.entries(table[layer]);
        const layerTracker:any = TRACKER[layer] = TRACKER[layer]||{};
        if(!weights?.length) {
          throw new Error(`Could not find weights for layer ${layer}`);
        }
        const index = new WeightedPicker( (weights).length, ( i:number ) => {
          const existing = layerTracker[weights[i][0]]||0;
          if(typeof ARGS.strict !== "undefined"){
            if( 
              Number(ARGS.strict) === 0 || (weights[i][1] < Number(ARGS.strict))
            ){
              if(existing>=weights[i][1]){
                return 0;
              }
            }
          }
          return (weights[i][1]);
        } ).pickOne();
        
        layerTracker[weights[index][0]] = (layerTracker[weights[index][0]]||0)+1;
        return index;
      } );
      const recipeCode = recipeEncode(recipe);
      if(UNIQUE_RECIPES[recipeCode]){
        // throw new Error("");
        recipeToImages
      }
      UNIQUE_RECIPES[recipeCode]=(UNIQUE_RECIPES[recipeCode]||0)+1;
      break;
    }catch(err){
      attempts++;
      process.stdout.clearLine(0);
      process.stdout.cursorTo(0);
      process.stdout.write(`Retry ${attempts}, ${recipe}`);
      continue;
    }
  }
  console.log(chalk.cyan(recipe.map(x=>String(x).padStart(4, "-")).join(" ")));
  return recipe;
}



function mergeImages( sliceFiles: string[], outFile: string, i:number, resize?:[number, number] ){
  // console.log({
  //   Merge: sliceFiles,
  //   To: outFile,
  //   Resize: resize,
  // });

  return new Promise<{
    meta: Metadata
  }>( async ( res, rej )=>{
        

    try {
      console.log(outFile);

      if(false){
        /* Use imagemagick */
        execSync([
          "convert -background none",
          sliceFiles.join(" "),
          "-layers flatten",
          outFile
        ].join(" "), {
          stdio: "inherit"
        });
  
      }else{
        /* use sharp (fast) */
        // console.log({
        //   sliceFiles
        // });
        // const timerId = randomBytes(8).toString('hex');
        // console.time(timerId);
        
        const sliceFiles1 = sliceFiles.filter(( $ )=>{
          if(!$) return;

          if($.indexOf("_none.png")>-1) {
            console.log(chalk.dim.strikethrough(`${$}`));
            return;
          }
          console.log(chalk.green(`${$}`));
          return true;
        });

        let img = sharp( resolve(sliceFiles1[0]) );
        const meta0 = await img.metadata();
        
        /* Prepare slices */
        const items: any[]  = [];
        for(let i=1; i<sliceFiles1.length; i++){
          const input = sliceFiles1[i];

          try{
            // console.log(input);
            const meta1 = await sharp(input).metadata();
            if(
              meta1.width !== meta0.width ||
              meta1.height !== meta0.height
            ){
              console.log(`Wrong size: ${input}`);
              console.log(meta1);
              return;
            }
            items.push({
              input: resolve(input),
              left:0,
              top:0,
            });

          }catch(err){
            console.group(chalk.red('Error combining: '));
            console.log(chalk.red(sliceFiles1.join("\n")));
            console.groupEnd();
            console.log(err);
            break;
          }
        }
        
        /* Compose slices */
        img.composite(items);
        
        /* Resize? */
        if(resize){
          const [width, height] = resize;
          img.resize({
            fit: "cover",
            width, 
            height,
          });
        }
  
        // console.log(await img.metadata());
        // contain
        // cover
        // fill
        // inside
        // outside
        mkdirSync(dirname(outFile), {recursive:true});
  
        
        img.toFile( outFile, async (err, info) => {
          if ( err ) {
            return rej( err );
          }  
          const meta = await img.metadata();
          // console.timeEnd(timerId);
          res( {
            meta
          } );
          img.destroy();

          try{
            const dst =`./outputs-ord/token-${i}.png`;
            mkdirSync(dirname(dst), { recursive: true });
            linkSync(outFile, dst);
          }catch(err:any){
            if (err.message === "EEXIST"){
              return;
            }
          }
        } );
  
      }      
    }
    catch ( err ) {
      rej( err );
    }
  } );


}
const ARGS = minimist(process.argv.slice(2));



function loadWeights(file:string){
  const weights = readYaml<WeightTable>(file);
  if(!weights) return {};
  const out:WeightTable = {};
  Object.keys(weights).map(( l )=>{
    out[l] = {};
    Object.keys(weights[l]).map(( s )=>{ 
      out[l][s.trim()] =  weights[l][s];
    });
  });
  return out;
}


const layerNames = [
  "1-background",
  "2-skin",
  "3-clothes",
  "4-collar",
  "5-paw",
  "6-mouth",
  "7-eyes",
  "8-hat",
];

(async function main(){
  // Main

  /* Load layers */
  LAYERS = (loadLayers());

  console.log(ARGS);

  /* Rarity Table */

  /* 
    From google drive:
    File > Download > CSV 
    ==> ./weights.csv
  */
  
  let weights:Record<string, Record<string, number>> = {};

  const rarCSV = String(ARGS.rarity || "./weights.csv");
  if(rarCSV){
    for(let i=0; i<8; i++){
      let data = readCSV(rarCSV, ",", i*4, 4);
      let layerFolder = layerNames[i];
      const [id, layerName] = layerFolder.split("-");

      weights[layerFolder] = data
        .filter(( row )=>{ 
          if(Object.values(row)[1]==="") return false;
          if(String(Object.values(row)[1])?.match(/^(total)?$/gi)) return false;
          return true;
        })
        .reduce(( $, row )=>{ 
          const name = layerName+'_'+String(row["name"]).trim()+".png";
          const weight = Number(String(row['weight #']).replace(/[^\d]/gi,""));
          $[name] = weight;
          return $;
      }, {} as any) as Record<string, number>;
    }
    console.log(weights);
    
  }

  writeYaml("./rarity-spec.yml", weights);


  /* Init */
  // if(ARGS.init){
  //   console.log("Init...");
    
  //   writeYaml("layers.json", LAYERS);

  //   const weights:WeightTable = LAYERS.reduce(( $, layer )=>{ 
  //     $[basename(layer.path)] = layer.slices.reduce(( $, slice, s)=>{
  //       const file = basename(slice);
  //       $[file.padEnd(50, " ")] = Math.round(100/(s+1));
  //       return $;
  //     }, {} as any);

  //     return $;
  //   }, {} as any);

  //   console.log(weights);

  //   writeYaml("weights.yaml", weights);

  //   return;
  // }

  /* Generate image for --recipe */

  const resize = (<string>ARGS.resize)?.split(/x/i)?.map(Number) as [number, number] || null;
  if(resize){
    console.log(`+ RESIZE: ${resize}`);
  }

  if(ARGS.recipe){
    const recipe =  recipeDecode(ARGS.recipe);
    console.log(`-> Generate: ${recipe}`);
    const outName = recipeEncode(recipe);
    const images = recipeToImages(weights, recipe);
    
    mergeImages(images, `./outputs/${outName}.png`, 0, resize).then((  )=>{ 

    });

    return;
  }

  /* Generate --max number of images */

  // const wts = ARGS.wts || './weights.yaml';
  // let weights: WeightTable|undefined = undefined;
  // if(wts){
  //   console.log(`+ WEIGHTS ${wts}`);
  //   console.log(weights);
  //   weights = loadWeights(wts);
  // }



  if('max' in ARGS){
    writeFileSync("./recipes.txt", "");
    const maxImages = Number(ARGS.max)||0;
    console.log(`-> Generate many: ${maxImages}`);

    for(let i =1; i<=maxImages; i++) {
      console.log(chalk.bold([i,maxImages].join("/")));
      let recipe = randomRecipe(weights);
      const outName = recipeEncode(recipe);
      appendFileSync("./recipes.txt", `${outName}\n`);
    }
    console.log(`
Created ./recipes.txt. Renerate images using: 

    ./images gen --render recipes.txt

    `);
  }

  /* Render */
  if('render' in ARGS){
    const timeStarted = Date.now();
    let numTasks = 0;

    const recipes = readList( 
      (typeof (ARGS.render) === "string") ? ARGS.render : "./recipes.txt"
    );

    console.log(`Rendering ${recipes.length} recipes...`);
    const maxImages = recipes.length;

    for(let i = 0; i < maxImages; i++) {
      const recipe = recipeDecode(recipes[i]);
      const images = recipeToImages(weights, recipe);
      const outName = recipeEncode(recipe);
      const outFile =`./outputs/${outName}.png`;
      if(!existsSync(outFile)){
        
      }

      await new Promise<void>(( res )=>{ 
        const check = ()=>{
          if( numTasks < cpus().length){
            return res();
          }
          setTimeout(check, 250);
        }
        check();
      });
      numTasks ++;
      mergeImages(images, outFile, i, resize).then((  )=>{ 
        numTasks --;
      });
      
      const msElapsed = Date.now()-timeStarted;
      const msPerImage = msElapsed/i;

      console.log(Object.entries({
        progress: `${ String((100*i/maxImages).toFixed(1)).padStart(5," ") }%  ${(i)}/${maxImages}`,
        msPerImage: msPerImage.toFixed(1),
        minsElapsed: (msElapsed/60000).toFixed(2),
        minsRemain: ((msPerImage/60000)*(maxImages-i)).toFixed(2),
      }).map(( [a,b] )=>{ 
        return [
          chalk.bold(String(a).padEnd(30,"·")),
          b
        ].join(" ")
      }).join("\n"));
    }
  }

  // console.log(TRACKER);
  writeYaml('rarity-report.yml', TRACKER);
  

})().then(( ...args:any )=>{ 
  // Done
  console.log(...args);
}).catch(( err )=>{
  // Error
  console.error(err);
});


process.on("SIGINT", (  )=>{  
  console.log("-- creating report... --");
  // console.log(TRACKER);
  writeYaml('rarity-report.yml', TRACKER);
  process.exit(1);
})

